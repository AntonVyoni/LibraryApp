--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.2
-- Dumped by pg_dump version 12.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE java_2_library;
--
-- Name: java_2_library; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE java_2_library WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'Swedish_Sweden.1252' LC_CTYPE = 'Swedish_Sweden.1252';


ALTER DATABASE java_2_library OWNER TO postgres;

\connect java_2_library

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: last_update(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.last_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.last_update := now();
  return NEW;
END;
$$;


ALTER FUNCTION public.last_update() OWNER TO postgres;

--
-- Name: max_loan_amount_proc(date, date, integer, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.max_loan_amount_proc(loan_date date, return_date date, fk_account_id integer, fk_inventory_id integer)
    LANGUAGE plpgsql
    AS $_$
DECLARE loan_count integer := 0;
BEGIN
INSERT INTO loan
(loan_date, return_date, fk_account_id, fk_inventory_id)
VALUES
($1, $2, $3, $4);
  DROP TABLE IF EXISTS loan_count;
  SELECT COUNT(*) INTO loan_count
  FROM loan
  GROUP BY loan.fk_account_id;
  IF (loan_count > (SELECT lending_limit FROM account_role
					JOIN account
					ON account.fk_role_id = account_role.role_id
				   WHERE account.fk_role_id = account_role.role_id
				   AND account.account_id = $3))
  THEN
    RAISE EXCEPTION 'Långräns uppnådd';
	ELSE RAISE NOTICE 'Lån genomfört';
  END IF;
  END;
  $_$;


ALTER PROCEDURE public.max_loan_amount_proc(loan_date date, return_date date, fk_account_id integer, fk_inventory_id integer) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dvd; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dvd (
    dvd_id integer NOT NULL,
    genre character varying(50) NOT NULL,
    "åldersgräns" integer NOT NULL,
    "lånetid" integer NOT NULL
);


ALTER TABLE public.dvd OWNER TO postgres;

--
-- Name: DVD_dvd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."DVD_dvd_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."DVD_dvd_id_seq" OWNER TO postgres;

--
-- Name: DVD_dvd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."DVD_dvd_id_seq" OWNED BY public.dvd.dvd_id;


--
-- Name: account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account (
    account_id integer NOT NULL,
    registration_date date DEFAULT CURRENT_DATE NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    phone_number character varying(20) NOT NULL,
    email character varying(100) NOT NULL,
    last_activity date DEFAULT CURRENT_DATE,
    last_update date DEFAULT CURRENT_DATE NOT NULL,
    fk_role_id integer NOT NULL,
    current_loans integer,
    password character varying
);


ALTER TABLE public.account OWNER TO postgres;

--
-- Name: account_account_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_account_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_account_id_seq OWNER TO postgres;

--
-- Name: account_account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_account_id_seq OWNED BY public.account.account_id;


--
-- Name: account_fk_role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_fk_role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_fk_role_id_seq OWNER TO postgres;

--
-- Name: account_fk_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_fk_role_id_seq OWNED BY public.account.fk_role_id;


--
-- Name: account_role; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_role (
    role_id integer NOT NULL,
    role_name character varying(50) NOT NULL,
    description character varying(255) NOT NULL,
    lending_limit integer NOT NULL,
    last_update date DEFAULT CURRENT_DATE NOT NULL
);


ALTER TABLE public.account_role OWNER TO postgres;

--
-- Name: account_role_role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_role_role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_role_role_id_seq OWNER TO postgres;

--
-- Name: account_role_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_role_role_id_seq OWNED BY public.account_role.role_id;


--
-- Name: author_or_director; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.author_or_director (
    author_id integer NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    last_update date DEFAULT CURRENT_DATE NOT NULL
);


ALTER TABLE public.author_or_director OWNER TO postgres;

--
-- Name: author_or_director_author_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.author_or_director_author_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.author_or_director_author_id_seq OWNER TO postgres;

--
-- Name: author_or_director_author_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.author_or_director_author_id_seq OWNED BY public.author_or_director.author_id;


--
-- Name: book; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.book (
    "ämnesord" character varying(255) NOT NULL,
    referenslitteratur boolean NOT NULL,
    kurslitteratur boolean NOT NULL,
    book_id integer NOT NULL,
    isbn character varying(255) DEFAULT 'ISBN saknas'::character varying NOT NULL
);


ALTER TABLE public.book OWNER TO postgres;

--
-- Name: book_book_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.book_book_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.book_book_id_seq OWNER TO postgres;

--
-- Name: book_book_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.book_book_id_seq OWNED BY public.book.book_id;


--
-- Name: inventory_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventory_item (
    inventory_id integer NOT NULL,
    barcode character varying(20) NOT NULL,
    last_update date DEFAULT CURRENT_DATE NOT NULL,
    fk_media_id integer NOT NULL,
    rented boolean DEFAULT false NOT NULL
);


ALTER TABLE public.inventory_item OWNER TO postgres;

--
-- Name: inventory_item_fk_media_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inventory_item_fk_media_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.inventory_item_fk_media_id_seq OWNER TO postgres;

--
-- Name: inventory_item_fk_media_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inventory_item_fk_media_id_seq OWNED BY public.inventory_item.fk_media_id;


--
-- Name: inventory_item_inventory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inventory_item_inventory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.inventory_item_inventory_id_seq OWNER TO postgres;

--
-- Name: inventory_item_inventory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inventory_item_inventory_id_seq OWNED BY public.inventory_item.inventory_id;


--
-- Name: loan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.loan (
    loan_id integer NOT NULL,
    loan_date date NOT NULL,
    return_date date NOT NULL,
    last_update date DEFAULT CURRENT_DATE NOT NULL,
    fk_account_id integer NOT NULL,
    fk_inventory_id integer,
    returned boolean DEFAULT false NOT NULL
);


ALTER TABLE public.loan OWNER TO postgres;

--
-- Name: loan_fk_account_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.loan_fk_account_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.loan_fk_account_id_seq OWNER TO postgres;

--
-- Name: loan_fk_account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.loan_fk_account_id_seq OWNED BY public.loan.fk_account_id;


--
-- Name: loan_fk_inventory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.loan_fk_inventory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.loan_fk_inventory_id_seq OWNER TO postgres;

--
-- Name: loan_fk_inventory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.loan_fk_inventory_id_seq OWNED BY public.loan.fk_inventory_id;


--
-- Name: loan_loan_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.loan_loan_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.loan_loan_id_seq OWNER TO postgres;

--
-- Name: loan_loan_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.loan_loan_id_seq OWNED BY public.loan.loan_id;


--
-- Name: loan_receipt; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.loan_receipt (
    receipt_id integer NOT NULL,
    title character varying(255) NOT NULL,
    au_first_name character varying(50) NOT NULL,
    au_last_name character varying(50) NOT NULL,
    isbn character varying(50) NOT NULL,
    loan_date date NOT NULL,
    return_date date NOT NULL,
    acc_full_name character varying(255) NOT NULL,
    email character varying(255) NOT NULL
);


ALTER TABLE public.loan_receipt OWNER TO postgres;

--
-- Name: loan_receipt_receipt_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.loan_receipt_receipt_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.loan_receipt_receipt_id_seq OWNER TO postgres;

--
-- Name: loan_receipt_receipt_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.loan_receipt_receipt_id_seq OWNED BY public.loan_receipt.receipt_id;


--
-- Name: media; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.media (
    media_id integer NOT NULL,
    title character varying(255) NOT NULL,
    description character varying(2000) NOT NULL,
    rental_duration integer NOT NULL,
    last_update date DEFAULT CURRENT_DATE NOT NULL,
    fk_book_id integer,
    fk_dvd_id integer,
    fk_paper_id integer,
    fk_author_or_director_id integer,
    country character varying(50) DEFAULT 'Sverige'::character varying NOT NULL,
    release_date date,
    fk_publisher_id integer
);


ALTER TABLE public.media OWNER TO postgres;

--
-- Name: media_media_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.media_media_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.media_media_id_seq OWNER TO postgres;

--
-- Name: media_media_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.media_media_id_seq OWNED BY public.media.media_id;


--
-- Name: paper; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.paper (
    paper_id integer NOT NULL,
    subject character varying NOT NULL,
    number character varying NOT NULL
);


ALTER TABLE public.paper OWNER TO postgres;

--
-- Name: paper_paper_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.paper_paper_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.paper_paper_id_seq OWNER TO postgres;

--
-- Name: paper_paper_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.paper_paper_id_seq OWNED BY public.paper.paper_id;


--
-- Name: publisher; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.publisher (
    publisher_id integer NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.publisher OWNER TO postgres;

--
-- Name: publisher_publisher_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.publisher_publisher_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.publisher_publisher_id_seq OWNER TO postgres;

--
-- Name: publisher_publisher_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.publisher_publisher_id_seq OWNED BY public.publisher.publisher_id;


--
-- Name: user_reservation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_reservation (
    reservation_id integer NOT NULL,
    reservation_date date NOT NULL,
    collection_deadline date NOT NULL,
    last_update date DEFAULT CURRENT_DATE NOT NULL,
    fk_account_id integer NOT NULL,
    fk_inventory_id integer NOT NULL,
    collected boolean DEFAULT false NOT NULL
);


ALTER TABLE public.user_reservation OWNER TO postgres;

--
-- Name: user_reservation_fk_account_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_reservation_fk_account_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_reservation_fk_account_id_seq OWNER TO postgres;

--
-- Name: user_reservation_fk_account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_reservation_fk_account_id_seq OWNED BY public.user_reservation.fk_account_id;


--
-- Name: user_reservation_fk_inventory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_reservation_fk_inventory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_reservation_fk_inventory_id_seq OWNER TO postgres;

--
-- Name: user_reservation_fk_inventory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_reservation_fk_inventory_id_seq OWNED BY public.user_reservation.fk_inventory_id;


--
-- Name: user_reservation_reservation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_reservation_reservation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_reservation_reservation_id_seq OWNER TO postgres;

--
-- Name: user_reservation_reservation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_reservation_reservation_id_seq OWNED BY public.user_reservation.reservation_id;


--
-- Name: account account_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account ALTER COLUMN account_id SET DEFAULT nextval('public.account_account_id_seq'::regclass);


--
-- Name: account_role role_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_role ALTER COLUMN role_id SET DEFAULT nextval('public.account_role_role_id_seq'::regclass);


--
-- Name: author_or_director author_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.author_or_director ALTER COLUMN author_id SET DEFAULT nextval('public.author_or_director_author_id_seq'::regclass);


--
-- Name: book book_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book ALTER COLUMN book_id SET DEFAULT nextval('public.book_book_id_seq'::regclass);


--
-- Name: dvd dvd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dvd ALTER COLUMN dvd_id SET DEFAULT nextval('public."DVD_dvd_id_seq"'::regclass);


--
-- Name: inventory_item inventory_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_item ALTER COLUMN inventory_id SET DEFAULT nextval('public.inventory_item_inventory_id_seq'::regclass);


--
-- Name: loan loan_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loan ALTER COLUMN loan_id SET DEFAULT nextval('public.loan_loan_id_seq'::regclass);


--
-- Name: loan_receipt receipt_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loan_receipt ALTER COLUMN receipt_id SET DEFAULT nextval('public.loan_receipt_receipt_id_seq'::regclass);


--
-- Name: media media_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media ALTER COLUMN media_id SET DEFAULT nextval('public.media_media_id_seq'::regclass);


--
-- Name: paper paper_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paper ALTER COLUMN paper_id SET DEFAULT nextval('public.paper_paper_id_seq'::regclass);


--
-- Name: publisher publisher_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.publisher ALTER COLUMN publisher_id SET DEFAULT nextval('public.publisher_publisher_id_seq'::regclass);


--
-- Name: user_reservation reservation_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_reservation ALTER COLUMN reservation_id SET DEFAULT nextval('public.user_reservation_reservation_id_seq'::regclass);


--
-- Data for Name: account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account (account_id, registration_date, first_name, last_name, phone_number, email, last_activity, last_update, fk_role_id, current_loans, password) FROM stdin;
\.
COPY public.account (account_id, registration_date, first_name, last_name, phone_number, email, last_activity, last_update, fk_role_id, current_loans, password) FROM '$$PATH$$/2969.dat';

--
-- Data for Name: account_role; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_role (role_id, role_name, description, lending_limit, last_update) FROM stdin;
\.
COPY public.account_role (role_id, role_name, description, lending_limit, last_update) FROM '$$PATH$$/2972.dat';

--
-- Data for Name: author_or_director; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.author_or_director (author_id, first_name, last_name, last_update) FROM stdin;
\.
COPY public.author_or_director (author_id, first_name, last_name, last_update) FROM '$$PATH$$/2974.dat';

--
-- Data for Name: book; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.book ("ämnesord", referenslitteratur, kurslitteratur, book_id, isbn) FROM stdin;
\.
COPY public.book ("ämnesord", referenslitteratur, kurslitteratur, book_id, isbn) FROM '$$PATH$$/2989.dat';

--
-- Data for Name: dvd; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dvd (dvd_id, genre, "åldersgräns", "lånetid") FROM stdin;
\.
COPY public.dvd (dvd_id, genre, "åldersgräns", "lånetid") FROM '$$PATH$$/2992.dat';

--
-- Data for Name: inventory_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventory_item (inventory_id, barcode, last_update, fk_media_id, rented) FROM stdin;
\.
COPY public.inventory_item (inventory_id, barcode, last_update, fk_media_id, rented) FROM '$$PATH$$/2976.dat';

--
-- Data for Name: loan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.loan (loan_id, loan_date, return_date, last_update, fk_account_id, fk_inventory_id, returned) FROM stdin;
\.
COPY public.loan (loan_id, loan_date, return_date, last_update, fk_account_id, fk_inventory_id, returned) FROM '$$PATH$$/2979.dat';

--
-- Data for Name: loan_receipt; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.loan_receipt (receipt_id, title, au_first_name, au_last_name, isbn, loan_date, return_date, acc_full_name, email) FROM stdin;
\.
COPY public.loan_receipt (receipt_id, title, au_first_name, au_last_name, isbn, loan_date, return_date, acc_full_name, email) FROM '$$PATH$$/2998.dat';

--
-- Data for Name: media; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.media (media_id, title, description, rental_duration, last_update, fk_book_id, fk_dvd_id, fk_paper_id, fk_author_or_director_id, country, release_date, fk_publisher_id) FROM stdin;
\.
COPY public.media (media_id, title, description, rental_duration, last_update, fk_book_id, fk_dvd_id, fk_paper_id, fk_author_or_director_id, country, release_date, fk_publisher_id) FROM '$$PATH$$/2983.dat';

--
-- Data for Name: paper; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.paper (paper_id, subject, number) FROM stdin;
\.
COPY public.paper (paper_id, subject, number) FROM '$$PATH$$/2994.dat';

--
-- Data for Name: publisher; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.publisher (publisher_id, name) FROM stdin;
\.
COPY public.publisher (publisher_id, name) FROM '$$PATH$$/2996.dat';

--
-- Data for Name: user_reservation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_reservation (reservation_id, reservation_date, collection_deadline, last_update, fk_account_id, fk_inventory_id, collected) FROM stdin;
\.
COPY public.user_reservation (reservation_id, reservation_date, collection_deadline, last_update, fk_account_id, fk_inventory_id, collected) FROM '$$PATH$$/2985.dat';

--
-- Name: DVD_dvd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."DVD_dvd_id_seq"', 13, true);


--
-- Name: account_account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_account_id_seq', 42, true);


--
-- Name: account_fk_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_fk_role_id_seq', 5, true);


--
-- Name: account_role_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_role_role_id_seq', 5, true);


--
-- Name: author_or_director_author_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.author_or_director_author_id_seq', 54, true);


--
-- Name: book_book_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.book_book_id_seq', 40, true);


--
-- Name: inventory_item_fk_media_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inventory_item_fk_media_id_seq', 1, false);


--
-- Name: inventory_item_inventory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inventory_item_inventory_id_seq', 94, true);


--
-- Name: loan_fk_account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.loan_fk_account_id_seq', 1, false);


--
-- Name: loan_fk_inventory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.loan_fk_inventory_id_seq', 1, false);


--
-- Name: loan_loan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.loan_loan_id_seq', 71, true);


--
-- Name: loan_receipt_receipt_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.loan_receipt_receipt_id_seq', 16, true);


--
-- Name: media_media_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.media_media_id_seq', 70, true);


--
-- Name: paper_paper_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.paper_paper_id_seq', 12, true);


--
-- Name: publisher_publisher_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.publisher_publisher_id_seq', 12, true);


--
-- Name: user_reservation_fk_account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_reservation_fk_account_id_seq', 1, false);


--
-- Name: user_reservation_fk_inventory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_reservation_fk_inventory_id_seq', 1, false);


--
-- Name: user_reservation_reservation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_reservation_reservation_id_seq', 8, true);


--
-- Name: dvd DVD_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dvd
    ADD CONSTRAINT "DVD_pkey" PRIMARY KEY (dvd_id);


--
-- Name: account account_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_email_key UNIQUE (email);


--
-- Name: account account_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_pkey PRIMARY KEY (account_id);


--
-- Name: account_role account_role_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_role
    ADD CONSTRAINT account_role_pkey PRIMARY KEY (role_id);


--
-- Name: author_or_director author_or_director_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.author_or_director
    ADD CONSTRAINT author_or_director_pkey PRIMARY KEY (author_id);


--
-- Name: book book_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.book
    ADD CONSTRAINT book_pkey PRIMARY KEY (book_id);


--
-- Name: inventory_item inventory_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_item
    ADD CONSTRAINT inventory_item_pkey PRIMARY KEY (inventory_id);


--
-- Name: loan loan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loan
    ADD CONSTRAINT loan_pkey PRIMARY KEY (loan_id);


--
-- Name: media media_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_pkey PRIMARY KEY (media_id);


--
-- Name: paper paper_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paper
    ADD CONSTRAINT paper_pkey PRIMARY KEY (paper_id);


--
-- Name: publisher publisher_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.publisher
    ADD CONSTRAINT publisher_pkey PRIMARY KEY (publisher_id);


--
-- Name: user_reservation user_reservation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_reservation
    ADD CONSTRAINT user_reservation_pkey PRIMARY KEY (reservation_id);


--
-- Name: fk_role_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fk_role_id ON public.account USING btree (fk_role_id);


--
-- Name: name_of_author; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX name_of_author ON public.author_or_director USING btree (first_name, last_name);


--
-- Name: name_of_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX name_of_user ON public.account USING btree (first_name, last_name);


--
-- Name: title; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX title ON public.media USING btree (title);


--
-- Name: account last_update; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER last_update BEFORE INSERT OR UPDATE ON public.account FOR EACH ROW EXECUTE FUNCTION public.last_update();


--
-- Name: account_role last_update; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER last_update BEFORE INSERT OR UPDATE ON public.account_role FOR EACH ROW EXECUTE FUNCTION public.last_update();


--
-- Name: author_or_director last_update; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER last_update BEFORE INSERT OR UPDATE ON public.author_or_director FOR EACH ROW EXECUTE FUNCTION public.last_update();


--
-- Name: inventory_item last_update; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER last_update BEFORE INSERT OR UPDATE ON public.inventory_item FOR EACH ROW EXECUTE FUNCTION public.last_update();


--
-- Name: loan last_update; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER last_update BEFORE INSERT OR UPDATE ON public.loan FOR EACH ROW EXECUTE FUNCTION public.last_update();


--
-- Name: media last_update; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER last_update BEFORE INSERT OR UPDATE ON public.media FOR EACH ROW EXECUTE FUNCTION public.last_update();


--
-- Name: user_reservation last_update; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER last_update BEFORE INSERT OR UPDATE ON public.user_reservation FOR EACH ROW EXECUTE FUNCTION public.last_update();


--
-- Name: account account_fk_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_fk_role_id_fkey FOREIGN KEY (fk_role_id) REFERENCES public.account_role(role_id) ON UPDATE CASCADE;


--
-- Name: inventory_item inventory_item_fk_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_item
    ADD CONSTRAINT inventory_item_fk_media_id_fkey FOREIGN KEY (fk_media_id) REFERENCES public.media(media_id) ON UPDATE CASCADE;


--
-- Name: loan loan_fk_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loan
    ADD CONSTRAINT loan_fk_account_id_fkey FOREIGN KEY (fk_account_id) REFERENCES public.account(account_id) ON UPDATE CASCADE;


--
-- Name: loan loan_fk_inventory_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loan
    ADD CONSTRAINT loan_fk_inventory_id_fkey FOREIGN KEY (fk_inventory_id) REFERENCES public.inventory_item(inventory_id) ON DELETE SET NULL;


--
-- Name: media media_fk_author_or_director_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_fk_author_or_director_id_fkey FOREIGN KEY (fk_author_or_director_id) REFERENCES public.author_or_director(author_id);


--
-- Name: media media_fk_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_fk_book_id_fkey FOREIGN KEY (fk_book_id) REFERENCES public.book(book_id);


--
-- Name: media media_fk_dvd_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_fk_dvd_id_fkey FOREIGN KEY (fk_dvd_id) REFERENCES public.dvd(dvd_id);


--
-- Name: media media_fk_paper_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_fk_paper_id_fkey FOREIGN KEY (fk_paper_id) REFERENCES public.paper(paper_id);


--
-- Name: media media_fk_publisher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_fk_publisher_id_fkey FOREIGN KEY (fk_publisher_id) REFERENCES public.publisher(publisher_id);


--
-- Name: user_reservation user_reservation_fk_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_reservation
    ADD CONSTRAINT user_reservation_fk_account_id_fkey FOREIGN KEY (fk_account_id) REFERENCES public.account(account_id) ON UPDATE CASCADE;


--
-- PostgreSQL database dump complete
--

